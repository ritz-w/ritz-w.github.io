module.exports = {
    get maintenance() {
        return require('./maintenance');
    }
};
