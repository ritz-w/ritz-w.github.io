const routing = require('../../services/routing');

module.exports = function siteRoutes() {
    return routing.bootstrap();
};
