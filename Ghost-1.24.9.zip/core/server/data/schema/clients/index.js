var sqlite3 = require('./sqlite3'),
    mysql = require('./mysql');

module.exports = {
    sqlite3: sqlite3,
    mysql: mysql
};
